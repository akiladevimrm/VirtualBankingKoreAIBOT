1.Go to home directory
  cd SDKApp
2.Install dependencies using following command
  npm install 
3.Download and then uncompress the Kore.ai Web SDK from https://github.com/Koredotcom/web-kore-sdk into the test application …/sdk folder of the SDKApp test application. The Web SDK contains the libraries used to communicate and run the bot in the test application using the Web/Mobile Client channel. You will need to configure settings in the index.html file for your computer.
4.Start SDKApp
  node startServer.js
5.Access the application in any browser using the following link
 http://localhost:3000

